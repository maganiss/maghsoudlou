require 'test_helper'

class JournalarticleTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

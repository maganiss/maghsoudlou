require 'test_helper'

class ProgressreportTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

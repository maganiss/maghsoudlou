require 'test_helper'

class CustomPageControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end

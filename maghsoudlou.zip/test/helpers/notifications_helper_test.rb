require 'test_helper'

class NotificationsHelperTest < ActionView::TestCase
end

require 'test_helper'

class ProgressreportsHelperTest < ActionView::TestCase
end

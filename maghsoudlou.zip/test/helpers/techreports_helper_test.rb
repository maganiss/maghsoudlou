require 'test_helper'

class TechreportsHelperTest < ActionView::TestCase
end

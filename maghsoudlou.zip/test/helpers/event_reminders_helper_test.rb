require 'test_helper'

class EventRemindersHelperTest < ActionView::TestCase
end

require 'test_helper'

class CustomPageHelperTest < ActionView::TestCase
end

require 'test_helper'

class ThesesHelperTest < ActionView::TestCase
end

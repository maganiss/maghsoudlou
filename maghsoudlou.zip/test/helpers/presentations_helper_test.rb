require 'test_helper'

class PresentationsHelperTest < ActionView::TestCase
end

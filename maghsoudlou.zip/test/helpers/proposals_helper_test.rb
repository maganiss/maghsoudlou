require 'test_helper'

class ProposalsHelperTest < ActionView::TestCase
end

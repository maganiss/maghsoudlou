require 'test_helper'

class ConfarticlesHelperTest < ActionView::TestCase
end

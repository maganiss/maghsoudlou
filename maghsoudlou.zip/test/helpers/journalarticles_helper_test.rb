require 'test_helper'

class JournalarticlesHelperTest < ActionView::TestCase
end

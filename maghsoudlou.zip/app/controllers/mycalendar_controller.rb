class MycalendarController < ApplicationController
  def index
  end
end

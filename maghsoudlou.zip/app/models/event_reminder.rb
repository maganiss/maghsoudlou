class EventReminder < ActiveRecord::Base
end

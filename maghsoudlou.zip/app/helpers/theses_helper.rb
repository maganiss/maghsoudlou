module ThesesHelper
end
